from flask_restful import Resource, reqparse
from models.enrollment import Enrollment
from models.course import Course
from models.student import Student
from models import db

class EnrollmentResource(Resource):
    def post(self, student_id):
        student = Student.query.get(student_id)
        if not student:
            return {'error': 'ENROLLMENT002: Student does not exist'}, 404

        parser = reqparse.RequestParser()
        parser.add_argument('course_id', type=int, required=True, help='ENROLLMENT001: Course does not exist')
        args = parser.parse_args()

        course = Course.query.get(args['course_id'])
        if not course:
            return {'error': 'ENROLLMENT001: Course does not exist'}, 404

        enrollment = Enrollment(student_id=student_id, course_id=args['course_id'])
        db.session.add(enrollment)
        db.session.commit()

        return {'message': 'Enrollment created successfully'}, 201

    def get(self, student_id):
        student = Student.query.get(student_id)
        if not student:
            return {'error': 'Student not found'}, 404

        enrollments = Enrollment.query.filter_by(student_id=student_id).all()
        return [{'enrollment_id': e.enrollment_id, 'course_id': e.course_id} for e in enrollments], 200

    def delete(self, student_id, course_id):
        enrollment = Enrollment.query.filter_by(student_id=student_id, course_id=course_id).first()
        if not enrollment:
            return {'error': 'ENROLLMENT003: Enrollment does not exist'}, 404

        db.session.delete(enrollment)
        db.session.commit()
        return {'message': 'Enrollment deleted successfully'}, 200
