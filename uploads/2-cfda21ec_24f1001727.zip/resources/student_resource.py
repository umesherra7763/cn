from flask_restful import Resource, reqparse
from models.student import Student
from models import db

student_parser = reqparse.RequestParser()
student_parser.add_argument('roll_number', type=str, required=True, help='STUDENT001: Roll Number required')
student_parser.add_argument('first_name', type=str, required=True, help='STUDENT002: First Name is required')
student_parser.add_argument('last_name', type=str)

class StudentResource(Resource):
    def get(self, student_id=None):
        if student_id:
            student = Student.query.get(student_id)
            if student:
                return {'student_id': student.student_id, 'roll_number': student.roll_number, 'first_name': student.first_name}, 200
            return {'error': 'Student not found'}, 404
        return {'error': 'Student ID required'}, 400

    def post(self):
        args = student_parser.parse_args()
        if Student.query.filter_by(roll_number=args['roll_number']).first():
            return {'error': 'STUDENT003: Roll Number already exists'}, 409

        new_student = Student(roll_number=args['roll_number'], first_name=args['first_name'], last_name=args.get('last_name'))
        db.session.add(new_student)
        db.session.commit()
        return {'message': 'Student created successfully', 'student_id': new_student.student_id}, 201

    def put(self, student_id):
        student = Student.query.get(student_id)
        if not student:
            return {'error': 'Student not found'}, 404

        args = student_parser.parse_args()
        student.roll_number = args['roll_number']
        student.first_name = args['first_name']
        student.last_name = args.get('last_name')

        db.session.commit()
        return {'message': 'Student updated successfully'}, 200

    def delete(self, student_id):
        student = Student.query.get(student_id)
        if not student:
            return {'error': 'Student not found'}, 404

        db.session.delete(student)
        db.session.commit()
        return {'message': 'Student deleted successfully'}, 200
