from flask_restful import Resource, reqparse
from models.course import Course
from models import db

course_parser = reqparse.RequestParser()
course_parser.add_argument('course_name', type=str, required=True, help='COURSE001: Course Name is required')
course_parser.add_argument('course_code', type=str, required=True, help='COURSE002: Course Code is required')
course_parser.add_argument('course_description', type=str)

class CourseResource(Resource):
    def get(self, course_id=None):
        if course_id:
            course = Course.query.get(course_id)
            if course:
                return {'course_id': course.course_id, 'course_name': course.course_name, 'course_code': course.course_code}, 200
            return {'error': 'Course not found'}, 404
        return {'error': 'Course ID required'}, 400

    def post(self):
        args = course_parser.parse_args()
        if Course.query.filter_by(course_code=args['course_code']).first():
            return {'error': 'COURSE003: Course Code already exists'}, 409

        new_course = Course(course_name=args['course_name'], course_code=args['course_code'], course_description=args.get('course_description'))
        db.session.add(new_course)
        db.session.commit()
        return {'message': 'Course created successfully', 'course_id': new_course.course_id}, 201

    def put(self, course_id):
        course = Course.query.get(course_id)
        if not course:
            return {'error': 'Course not found'}, 404

        args = course_parser.parse_args()
        course.course_name = args['course_name']
        course.course_code = args['course_code']
        course.course_description = args.get('course_description')

        db.session.commit()
        return {'message': 'Course updated successfully'}, 200

    def delete(self, course_id):
        course = Course.query.get(course_id)
        if not course:
            return {'error': 'Course not found'}, 404

        db.session.delete(course)
        db.session.commit()
        return {'message': 'Course deleted successfully'}, 200
