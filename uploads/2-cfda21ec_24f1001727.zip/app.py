from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api
from config import Config
from models import db
from resources.course_resource import CourseResource
from resources.student_resource import StudentResource
from resources.enrollment_resource import EnrollmentResource

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)
api = Api(app)

# Course Routes
api.add_resource(CourseResource, '/api/course', '/api/course/<int:course_id>')

# Student Routes
api.add_resource(StudentResource, '/api/student', '/api/student/<int:student_id>')

# Enrollment Routes
api.add_resource(EnrollmentResource, '/api/student/<int:student_id>/course', '/api/student/<int:student_id>/course/<int:course_id>')

if __name__ == '__main__':
    app.run(debug=True)
